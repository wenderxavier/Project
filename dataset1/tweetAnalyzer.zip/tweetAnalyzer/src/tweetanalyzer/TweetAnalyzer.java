/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tweetanalyzer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Wender
 */
public class TweetAnalyzer {
    
    public static void insertLocation() throws FileNotFoundException, IOException{
        BufferedReader arquivo = new BufferedReader(new FileReader ("usersLocation.txt"));
        BufferedWriter output = new BufferedWriter( new FileWriter ("userLocationUpdated.txt"));
        BufferedReader input = new BufferedReader( new InputStreamReader(System.in));
        String [] palavras;
        String line;
        while(arquivo.ready()){
            line = arquivo.readLine();
            palavras = line.split(" ");
            if(palavras.length == 1){
                System.out.println("Type the locality of user " + palavras[0] );
                output.write(palavras [0] + " ");
                output.write(input.readLine());
                output.flush();
                output.newLine();
            }
            else{
                output.write(line);
                output.flush();
                output.newLine();
            }
        }
        output.close();
        arquivo.close();
    }
    
    public static void getLocality() throws FileNotFoundException, IOException{
        BufferedReader arquivo = new BufferedReader(new FileReader ("usersLocation.txt"));
        BufferedWriter output = new BufferedWriter( new FileWriter ("coordenadaGeografica.txt"));
        String [] palavras;
        while( arquivo.ready() ){
            palavras = arquivo.readLine().split(" ");
            for(int i=1; i<palavras.length; i++){
                output.write(palavras[i]);
                output.flush();
            }
            output.newLine();
        }
            output.close();        
    }
    
    public static void getHashtags() throws FileNotFoundException, IOException{
        BufferedReader arquivo = new BufferedReader(new FileReader ("TwitterHashtag.txt"));
        String [] palavras;
        while(arquivo.ready()){
            palavras = arquivo.readLine().split(" ");
                for(int i=0; i<palavras.length; i++){
                if(palavras[i].startsWith("#") ){
                    System.out.println(palavras[i]);
                }
            }
        }
    }
    
    public static void getSentimentTweet() throws FileNotFoundException, IOException{
        BufferedReader arquivo = new BufferedReader(new FileReader ("TwitterHashtag.txt"));
        String[] words;
        while(arquivo.ready()){
            words = arquivo.readLine().split(" ");
            for( int i=0; i<words.length; i++){
                if(words[i].startsWith("#negdilma")){
                    System.out.print("-1");
                } else if(words[i].startsWith("#posdilma")){
                    System.out.print("1");
                } else if(words[i].startsWith("#negaecio")){
                    System.out.print("-2");
                } else if(words[i].startsWith("#posaecio")){
                    System.out.print("2");
            } else if(words[i].startsWith("more")){
                System.out.println("-------------------");
                }
            }
        }
    }

    public static void main(String[] args) throws FileNotFoundException, IOException {
        //insertLocation();
        //getLocality();
        //getHashtags();
        getSentimentTweet();
    }

}
